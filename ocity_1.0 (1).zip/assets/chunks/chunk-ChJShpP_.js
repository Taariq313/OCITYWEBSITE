import{a as i,j as c,q as m,b as N}from"./chunk-BBHj_3TP.js";const x=i.forwardRef((e,t)=>c.jsx("body",{...e,ref:t}));x.displayName="Body";const b="div",R=i.forwardRef(({tag:e,...t},r)=>{const a=m(t)??e??b;return i.createElement(a,{...t,ref:r})});R.displayName="Box";const $="div",I=i.forwardRef(({tag:e,...t},r)=>{const a=m(t)??e??$;return i.createElement(a,{...t,ref:r})});I.displayName="Text";const S="h1",z=i.forwardRef(({tag:e,...t},r)=>{const a=m(t)??e??S;return i.createElement(a,{...t,ref:r})});z.displayName="Heading";const E=i.forwardRef(({children:e,...t},r)=>c.jsx("p",{...t,ref:r,children:e}));E.displayName="Paragraph";const L=i.forwardRef((e,t)=>{const{children:r,$webstudio$canvasOnly$assetId:a,...s}=e;return c.jsx("a",{...s,href:s.href??"#",ref:t,children:r})});L.displayName="Link";const j=i.forwardRef(({type:e="submit",children:t,...r},a)=>c.jsx("button",{type:e,...r,ref:a,children:t}));j.displayName="Button";var M=[16,32,48,64,96,128,256,384],h=[640,750,828,1080,1200,1920,2048,3840],f=[...M,...h],A=(e,t)=>{if(t){const s=/(^|\s)(1?\d?\d)vw/g,n=[];for(let d;d=s.exec(t);d)n.push(Number.parseInt(d[2],10));if(n.length){const d=Math.min(...n)*.01;return{widths:f.filter(l=>l>=h[0]*d),kind:"w"}}return{widths:f,kind:"w"}}if(e==null)return{widths:h,kind:"w"};const r=2;let a=f.findIndex(s=>s>=r*e);return a=a<0?f.length:a,{widths:f.slice(0,a+1),kind:"w"}},D=({src:e,width:t,quality:r,sizes:a,loader:s})=>{const{widths:n,kind:d}=A(t,a);return{sizes:!a&&d==="w"?"100vw":a,srcSet:n.map((l,o)=>`${s({src:e,quality:r,width:l})} ${d==="w"?l:o+1}${d}`).join(", "),src:s({src:e,quality:r,width:n[n.length-1]})}},g=e=>{if(typeof e=="number")return Math.round(e);if(typeof e=="string"){const t=Number.parseFloat(e);if(!Number.isNaN(t))return Math.round(t)}},k="(min-width: 1280px) 50vw, 100vw",V=80,H=e=>{try{return new URL(e),!0}catch{return!1}},T=e=>{const t=g(e.width),r=Math.max(Math.min(g(e.quality)??V,100),0);if(e.src!=null&&e.src!==""){if(e.srcSet==null&&e.optimize){const s=e.sizes??(e.width==null?k:void 0);return D({src:e.src,width:t,quality:r,sizes:s,loader:e.loader})}const a={src:H(e.src)?e.src:e.loader({src:e.src,format:"raw"})};return e.srcSet!=null&&(a.srcSet=e.srcSet),e.sizes!=null&&(a.sizes=e.sizes),a}},v=i.forwardRef(({quality:e,loader:t,optimize:r=!0,loading:a="lazy",decoding:s="async",...n},d)=>{const l=T({src:n.src,srcSet:n.srcSet,sizes:n.sizes,width:n.width,quality:e,loader:t,optimize:r})??{src:U};return c.jsx("img",{alt:"",...n,...l,decoding:s,loading:a,ref:d})});v.displayName="Image";var U=`data:image/svg+xml;base64,${btoa(`<svg
  width="140"
  height="140"
  viewBox="0 0 600 600"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
  >
  <rect width="600" height="600" fill="#DFE3E6" />
  <path
    fill-rule="evenodd"
    clip-rule="evenodd"
    d="M450 170H150C141.716 170 135 176.716 135 185V415C135 423.284 141.716 430 150 430H450C458.284 430 465 423.284 465 415V185C465 176.716 458.284 170 450 170ZM150 145C127.909 145 110 162.909 110 185V415C110 437.091 127.909 455 150 455H450C472.091 455 490 437.091 490 415V185C490 162.909 472.091 145 450 145H150Z"
    fill="#C1C8CD"
  />
  <path
    d="M237.135 235.012C237.135 255.723 220.345 272.512 199.635 272.512C178.924 272.512 162.135 255.723 162.135 235.012C162.135 214.301 178.924 197.512 199.635 197.512C220.345 197.512 237.135 214.301 237.135 235.012Z"
    fill="#C1C8CD"
  />
  <path
    d="M160 405V367.205L221.609 306.364L256.552 338.628L358.161 234L440 316.043V405H160Z"
    fill="#C1C8CD"
  />
</svg>`)}`;const F=i.forwardRef(({loading:e="lazy",width:t,height:r,optimize:a=!0,decoding:s,$webstudio$canvasOnly$assetId:n,...d},l)=>{const o=String(d.src??""),{imageLoader:y,renderer:C}=i.useContext(N);let u=s,w=o;return C==="canvas"&&(e="eager",u="sync",w=n??o,t!==void 0&&r!==void 0&&Number.isNaN(t)&&Number.isNaN(r)&&(a=!1,t=void 0,r=void 0)),c.jsx(v,{loading:e,decoding:u,optimize:a,width:t,height:r,...d,loader:y,src:o,ref:l},w)});F.displayName="Image";const Z="ul",_="ol",B=i.forwardRef(({ordered:e=!1,...t},r)=>i.createElement(e?_:Z,{...t,ref:r}));B.displayName="List";const O=i.forwardRef(({children:e,...t},r)=>c.jsx("li",{...t,ref:r,children:e}));O.displayName="ListItem";export{L as a,j as b,I as c,z as d,E as e,x as f,B as g,O as i,R as n,F as y};
